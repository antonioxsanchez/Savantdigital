# Savant Digital Co — Website

Built with React + Vite. Ready to deploy on Vercel.

---

## Deploy to Vercel (Step by Step)

### Option 1 — GitHub + Vercel (Recommended)

1. Create a free account at **github.com**
2. Create a new repository called `savant-digital-co`
3. Upload all these files into the repository
4. Go to **vercel.com** → sign up with your GitHub account
5. Click **Add New Project** → select your repository
6. Vercel auto-detects Vite — just click **Deploy**
7. Your site goes live at a `.vercel.app` URL instantly

To connect a custom domain (savantdigitalco.com):
- Go to your project in Vercel → Settings → Domains → Add your domain

---

### Option 2 — Vercel CLI (Fastest)

```bash
npm install -g vercel
cd savant-digital-co
npm install
vercel
```

Follow the prompts. Site is live in under 2 minutes.

---

## Local Development

```bash
npm install
npm run dev
```

Opens at http://localhost:5173

---

## Adding Your Logo

In `src/components/Navbar.jsx` and `src/components/Footer.jsx`, find the brand name block and add:

```jsx
<img src="/logo.png" style={{ width: 40, height: 40, objectFit: 'contain' }} />
```

Put your logo PNG in the `/public` folder.

---

## Adding Gallery Photos

In `src/pages/Gallery.jsx`, find the `PlaceholderImg` component and replace it with:

```jsx
const RealImg = ({ src, cat }) => (
  <div style={{ position: 'relative', height: 200, overflow: 'hidden' }}>
    <img src={src} alt={cat} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
  </div>
);
```

Then add your photo paths to the `ITEMS` array.

---

## File Structure

```
savant-digital-co/
├── index.html
├── vite.config.js
├── vercel.json
├── package.json
├── public/
│   └── (logo.png goes here)
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── index.css
    ├── theme.js
    ├── components/
    │   ├── Navbar.jsx
    │   ├── Footer.jsx
    │   ├── Icons.jsx
    │   └── UI.jsx
    └── pages/
        ├── Home.jsx
        ├── Services.jsx
        ├── Classes.jsx
        ├── Gallery.jsx
        ├── Book.jsx
        └── Contact.jsx
```

---

Built by Antonio Sanchez — Savant Digital Co
